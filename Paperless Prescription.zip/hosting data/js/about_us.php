<?php
	require_once("lib/functions.php");
	$db = new db_functions();
?>	
<html>
<head>
	<title>About Us</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>

<?php 
	require_once('header.php');
?>

	<div class="middle_section" style="min-height:560px">
		<div class="page_head_titles">About Us</div>


			<div class="form_container_1">
				<img src="images/commercial-led-lighting-buildings.png"
				style="width: 100%"
				height="341"/>

	
				
			

			</div>
				<style>
		body{
			background-image: url("images/background-websites-26-desktop-background-and-wallpaper-900x568.jpg");
			background-repeat:no-repeat;

			background-size:cover; 
		}
	</style>


		
	</div>

		

<?php
	require_once('footer.php');
?>


</body>
</html>