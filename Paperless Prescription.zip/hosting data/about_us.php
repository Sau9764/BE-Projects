<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('header.php');
	?>
	<div class="middle_container" style="background-image:url('/images/aboutus.jpeg'); background-size:100% 100%;">
	<center>
	<div class="about_us_img" style="background-image:url('/images/logo.jpg'); background-size:100% 100%;">
		</div >
		<div class="text">
		<h2><b>Dr. Abhijeet S. Waghchavare</b></h2>
		<h2>(M.B.B.S. M.S. D.N.S D. Ortho)</h2>
		<h3>Orthopedic Surgeon</h3>
		<marquee>Shop no. 20, 31, Vaishnavi plaza,
		near D mart, Jule Solapur-413004</marquee>
		Ph. no.<b>9673114309</b>
		</div>
	</div>
	<?php
		require_once('footer.php');
	?>
</body>
</html>