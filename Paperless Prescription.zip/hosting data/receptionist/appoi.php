<?php
	require_once('../lib/db_functions.php');
	$db = new database_functions();
	if(!isset($_SESSION['current_login_user'])){
		header("Location:/index.php");
	}
	$common_msg		=		"";
	$flag	=		0;
	$contact_number_error		=		"";
	$app_doctor_name		=	"";
	if(isset($_POST['submit_btn'])){
		$app_name		=	$_POST['app_name'];
		$app_contact_no	=	$_POST['app_contact_no'];
		$app_time		=	$_POST['app_time'];
		$app_doctor		=	$_POST['app_doctor'];
		$app_desc		=	$_POST['app_desc'];
		if(!is_numeric($app_contact_no)){
			$contact_number_error	=	"Please enter numeric contact number";
			$flag	=	1;
		}else if(strlen($app_contact_no)!=10){
			$contact_number_error	=	"Please enter valid 10 digit contact number";	
			$flag	=	1;
		}
		if($flag==0){
			if($db->register_app($app_name,$app_contact_no,$app_time,$app_doctor,$app_desc)){
				$common_msg	= "Registration successful";
			}else{
				$common_msg	= "Failed";
			}
		}
	}
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container" style="background-image:url('/images/back.jpg')">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
		<form action="/receptionist/appoi.php" method="post">
			<div class="form_container">
			<br>
				<div class="common_msg" style="background-color:#F8F8FF;">
					<?php
						echo $common_msg;
					?>
				</div>
				<br>
						<div class="text">Enter Name:<br></div>
						<input type="text" name="app_name" class="f_textbox" style="margin-top:3px;"required />
						<br>
						<span class="error_indicator">
							<?php echo $contact_number_error; ?>
						</span>
						<div class="text">Enter Contact Number:<br></div>
						<input type="text" name="app_contact_no" class="f_textbox" required style="margin-top:3px;"/>
						<br>
						<div class="text">Please Select Time:<br></div>
						<select name="app_time" class="f_textbox" style="margin-top:3px;" required>
							<option value="9.00 Am">09.00 Am</option>
							<option value="10.00 Am">10.00 Am</option>
							<option value="11.00 Am">11.00 Am</option>
							<option value="12.00 Pm">12.00 Pm</option>
							<option value="03.00 to 05.00 Pm">03.00 to 05.00 Pm</option>
							<option value="Not Given">other</option>
						</select>
						<br>
						<div class="text">Please Select Doctor:<br></div>
						<select name="app_doctor" class="f_textbox" style="margin-top:3px;" required>
						<?php
							$doc_data	=	array();
							$doc		=	"doctor";
							$doc_data	=	$db->get_all_doc_data($doc);
							if(!empty($doc_data)){
								$counter = 0;
								foreach($doc_data as $record){
								$result_id			=	$doc_data[$counter][0];
								$app_doctor_name	=	$doc_data[$counter][1];
								$result_email_id	=	$doc_data[$counter][2];
								$result_contact_no	=	$doc_data[$counter][3];
								$result_user_job	=	$doc_data[$counter][4];
								$result_gender		=	$doc_data[$counter][5];
								$result_dob			=	$doc_data[$counter][6];
								$result_password	=	$doc_data[$counter][7];
								$result_date		=	$doc_data[$counter][8];
								$result_time		=	$doc_data[$counter][9];
						?>
								<option value="<?php echo $app_doctor_name; ?>" ><?php echo $app_doctor_name; ?> </option>
						<?php
									$counter++;
								}
							}	
						?>
						</select>
						<div class="text">Enter About Appointment:<br></div>
						<input type="text" name="app_desc" class="f_textbox" style="margin-top:3px;" />
						<br>
					<input type="submit" name="submit_btn" class="submit_btn" value="REGISTER ME" />
			</div>
		</form>
	</div>
	<?php
				require_once('../left_panel.php');
		?>	
</div>
	<?php
		require_once('../footer.php');
	?>
</body>
</html>