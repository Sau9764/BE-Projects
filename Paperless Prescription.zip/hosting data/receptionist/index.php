<?php
	require_once('../lib/db_functions.php');
	$db = new database_functions();
	if(!isset($_SESSION['current_login_user'])){
		header("Location:/index.php");
	}
	$email_id	=	$_SESSION['current_login_user'];
	$contact_number_error		=		"";
	$disease_error				=		"";
	$common_msg		=	"";
	$flag	=		0;
	if(isset($_POST['submit_btn'])){
		$patient_name		=	$_POST['patient_name'];
		$patient_email		=	$_POST['patient_email'];
		$contact_number		=	$_POST['contact_number'];
		$disease_type		=	$_POST['disease_type'];
		$patient_age		=	$_POST['patient_age'];
		$patient_bill		=	$_POST['patient_bill'];
		if(!is_numeric($contact_number)){
			$contact_number_error	=	"Please enter numeric contact number";
			$flag	=	1;
		}
		else if(strlen($contact_number)!=10){
			$contact_number_error	=	"Please enter valid 10 digit contact number";	
			$flag	=	1;
		}
		if($flag==0){
			$patient_exist	=	$db->get_patient_exist_value($patient_name);
			if($patient_exist==""){
				//Save the data
				if($db->register_patient($patient_name,$patient_email,$contact_number,$disease_type,$patient_age,$patient_bill)){
					$common_msg	= "Registration successful";
				}else{
					$common_msg	= "Failed";
				}
			}else{
				$common_msg	= "This Patient is already exist";
			}
		}
	}
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($email_id);
	$user_job	=	"admin";
	$count			=	$db->get_admin_count($user_job);
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
	<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
					<div class="common_msg" style="background-color:#F8F8FF;">
						<?php
							echo $common_msg;
						?>
					</div>
				<br>
			<form action="/receptionist/index.php" method="post">
					<div class="entry_pannel1">
						<div class="text">Enter Patient Name:<br></div>
						<input type="text" name="patient_name" class="f_textbox" style="margin-top:3px;"required />
						<br>
						<div class="text">Enter Patient Email ID:<br></div>
						<input type="email" name="patient_email" class="f_textbox" style="margin-top:3px;" />
						<br>
							<br>	
							<span class="error_indicator">
								<?php echo $contact_number_error; ?>
							</span>
						<div class="text">Enter Patient Contact Number:<br></div>
						<input type="text" name="contact_number" class="f_textbox" required style="margin-top:3px;"/>
						<br>
					</div>
					<div class="entry_pannel2">
						<br>
						<span class="error_indicator">
							<?php echo $disease_error; ?>
						</span>
						<div class="text">Please Select Disease:<br></div>
						<select name="disease_type" class="f_textbox" style="margin-top:3px;" required>
							<option value="Select disease">Select Disease</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">Other</option>
						</select>
						<br>
						<div class="text">Enter Patient Age:<br></div>
						<input type="text" name="patient_age" class="f_textbox" style="margin-top:3px;" required />
						<br>
						<div class="text">Enter Patient Checkup Fees:<br></div>
						<input type="text" name="patient_bill" class="f_textbox" style="margin-top:3px;" required />
						<br>
					</div>
					<center>
					<input type="submit" name="submit_btn" class="submit_btn" value="ADD PATIENT" style="margin:-90px;" />
					</center>
					<a href="/receptionist/appoi.php" class="app_button">Create an Appointments..</a>
				</form>
		</div>
		<?php
				require_once('../left_panel.php');
		?>		
	</div>
	<?php
		require_once('../footer.php');
	?>
</body>
</html>