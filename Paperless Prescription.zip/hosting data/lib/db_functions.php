<?php
	session_start();
	date_default_timezone_set("Asia/kolkata");
	class database_functions{
		private $con;
		function __construct(){
			$this->con	=	new mysqli("localhost","root","","paperless_precreption");
		}
		function get_user_data_from_email($email_id){
			if($stmt_select = $this->con->prepare("SELECT `id`, `name`, `email_id`, `contact_no`, `user_job`, `gender`, `dob`, `password`,`profile_image`, `date`, `time` FROM `hospital_users` WHERE `email_id` = ?")){
				$stmt_select->bind_param("s",$email_id);
				$stmt_select->bind_result($result_id,$result_name,$result_email_id,$result_contact_no,$result_user_job,$result_gender,$result_dob,$result_password,$result_profile_image,$result_date,$result_time);
				if($stmt_select->execute()){
					$data_container	=	array();
					if($stmt_select->fetch()){
						$data_container[0]	=	$result_id;
						$data_container[1]	=	$result_name;
						$data_container[2]	=	$result_email_id;
						$data_container[3]	=	$result_contact_no;
						$data_container[4]	=	$result_user_job;
						$data_container[5]	=	$result_gender;
						$data_container[6]	=	$result_dob;
						$data_container[7]	=	$result_password;
						$data_container[8]	=	$result_profile_image;
						$data_container[9]	=	$result_date;
						$data_container[10]	=	$result_time;
						return $data_container;
					}
				}
				return false;
			}
		}
		
		function update_profile_image($actual_image_name,$email_id){
			if($stmt_update = $this->con->prepare("UPDATE `hospital_users` SET `profile_image`=? WHERE `email_id` = ?")){
				$stmt_update->bind_param("ss",$actual_image_name,$email_id);
				if($stmt_update->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function get_user_profile_image($email_id){
			if($stmt_select = $this->con->prepare("SELECT `profile_image` FROM `hospital_users` WHERE `email_id` = ?")){
				$stmt_select->bind_param("s",$email_id);
				$stmt_select->bind_result($result_profile_img);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_profile_img;
					}
					return false;
				}
			}
		}
		
		function update_user($user_name,$user_contact_no,$user_gender,$user_dob,$user_email){
			if($stmt_update = $this->con->prepare("UPDATE `hospital_users` SET `name`=?,`contact_no`=?,`gender`=?,`dob`=? WHERE `email_id` = ?")){
				$stmt_update->bind_param("sssss",$user_name,$user_contact_no,$user_gender,$user_dob,$user_email);
				if($stmt_update->execute()){
					return true;
				}else{
					return false;
				}
			}
		}

		function update_user_password($email_id,$new_pwd){
			if($stmt_update = $this->con->prepare("UPDATE `hospital_users` SET `password`=? WHERE `email_id` = ?")){
				$stmt_update->bind_param("ss",$new_pwd,$email_id);
				
				if($stmt_update->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function get_admin_count($admin){
			if($stmt_select = $this->con->prepare("SELECT count(*) FROM `hospital_users` WHERE `user_job` = ?")){
				$stmt_select->bind_param("s",$admin);
				$stmt_select->bind_result($result_count);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_count;
					}
					return false;
				}
			}
		}
		
		function get_doctor_count($doctor){
			if($stmt_select = $this->con->prepare("SELECT count(*) FROM `hospital_users` WHERE `user_job` = ?")){
				$stmt_select->bind_param("s",$doctor);
				$stmt_select->bind_result($result_count);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_count;
					}
					return false;
				}
			}
		}
		
		function get_receptionist_count($receptionist){
			if($stmt_select = $this->con->prepare("SELECT count(*) FROM `hospital_users` WHERE `user_job` = ?")){
				$stmt_select->bind_param("s",$receptionist);
				$stmt_select->bind_result($result_count);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_count;
					}
					return false;
				}
			}
		}
		
		function get_patient_count(){
			if($stmt_select = $this->con->prepare("SELECT count(*) FROM `patient_data`")){
				$stmt_select->bind_result($result_count);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_count;
					}
					return false;
				}
			}
		}
		
		function get_app_count(){
			if($stmt_select = $this->con->prepare("SELECT count(*) FROM `appointment_data`")){
				$stmt_select->bind_result($result_count);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_count;
					}
					return false;
				}
			}
		}
		
		function get_user_exist_value($user_email){
			if($stmt_select = $this->con->prepare("Select `id` from `hospital_users` where `email_id` = ?")){
				$stmt_select->bind_param("s",$user_email);
				$stmt_select->bind_result($result_id);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		function register_user($user_name,$user_email,$user_contact_no,$user_job,$user_gender,$user_dob,$user_password){
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			if($stmt_insert = $this->con->prepare("INSERT INTO `hospital_users`(`name`, `email_id`, `contact_no`, `user_job`, `gender`, `dob`, `password`, `date`, `time`) VALUES (?,?,?,?,?,?,?,?,?)")){
				$stmt_insert->bind_param("sssssssss",$user_name,$user_email,$user_contact_no,$user_job,$user_gender,$user_dob,$user_password,$date,$time);
				if($stmt_insert->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function get_all_doc_data($doc){
			if($stmt_select = $this->con->prepare("SELECT `id`, `name`, `email_id`, `contact_no`, `user_job`, `gender`, `dob`, `password`,`date`, `time` FROM `hospital_users` WHERE `user_job` =?")){	
				$stmt_select->bind_param("s",$doc);
				$stmt_select->bind_result($result_id,$result_doctor_name,$result_email_id,$result_contact_no,$result_user_job,$result_gender,$result_dob,$result_password,$result_date,$result_time);
				if($stmt_select->execute()){
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch()){
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_doctor_name;
						$data_container[$counter][2]	=	$result_email_id;
						$data_container[$counter][3]	=	$result_contact_no;
						$data_container[$counter][4]	=	$result_user_job;
						$data_container[$counter][5]	=	$result_gender;
						$data_container[$counter][6]	=	$result_dob;
						$data_container[$counter][7]	=	$result_password;
						$data_container[$counter][8]	=	$result_date;
						$data_container[$counter][9]	=	$result_time;
						$counter++;
					}
					if(!empty($data_container)){
						return $data_container;
					}else{
						return false;
					}	
				}
			}
		}
		
		function get_all_recept_data($recept){
			if($stmt_select = $this->con->prepare("SELECT `id`, `name`, `email_id`, `contact_no`, `user_job`, `gender`, `dob`, `password`,`date`, `time` FROM `hospital_users` WHERE `user_job` =?")){	
				$stmt_select->bind_param("s",$recept);
				$stmt_select->bind_result($result_id,$result_doctor_name,$result_email_id,$result_contact_no,$result_user_job,$result_gender,$result_dob,$result_password,$result_date,$result_time);
				if($stmt_select->execute()){
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch()){
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_doctor_name;
						$data_container[$counter][2]	=	$result_email_id;
						$data_container[$counter][3]	=	$result_contact_no;
						$data_container[$counter][4]	=	$result_user_job;
						$data_container[$counter][5]	=	$result_gender;
						$data_container[$counter][6]	=	$result_dob;
						$data_container[$counter][7]	=	$result_password;
						$data_container[$counter][8]	=	$result_date;
						$data_container[$counter][9]	=	$result_time;
						$counter++;
					}
					if(!empty($data_container)){
						return $data_container;
					}else{
						return false;
					}	
				}
			}
		}
		
		function get_patient_exist_value($patient_name){
			if($stmt_select = $this->con->prepare("Select `id` from `patient_data` where `patient_name` = ?")){
				$stmt_select->bind_param("s",$patient_name);
				$stmt_select->bind_result($result_id);
				if($stmt_select->execute()){
					if($stmt_select->fetch()){
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		function register_patient($patient_name,$patient_email,$contact_number,$disease_type,$patient_age,$patient_bill){
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			if($stmt_insert = $this->con->prepare("INSERT INTO `patient_data`(`patient_name`, `patient_email`, `contact_number`, `disease_type`, `patient_age`, `patient_bill`, `date`, `time`) VALUES (?,?,?,?,?,?,?,?)")){
				$stmt_insert->bind_param("ssssssss",$patient_name,$patient_email,$contact_number,$disease_type,$patient_age,$patient_bill,$date,$time);
				if($stmt_insert->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function get_all_patient_data(){
			if($stmt_select = $this->con->prepare("SELECT `id`, `patient_name`, `patient_email`, `contact_number`, `disease_type`, `patient_age`, `patient_bill`, `date`, `time` FROM `patient_data`")){	
				$stmt_select->bind_result($result_id,$result_patient_name,$result_patient_email,$result_contact_number,$result_disease_type,$result_patient_age,$result_patient_bill,$result_date,$result_time);
				if($stmt_select->execute()){
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch()){
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_patient_name;
						$data_container[$counter][2]	=	$result_patient_email;
						$data_container[$counter][3]	=	$result_contact_number;
						$data_container[$counter][4]	=	$result_disease_type;
						$data_container[$counter][5]	=	$result_patient_age;
						$data_container[$counter][6]	=	$result_patient_bill;
						$data_container[$counter][7]	=	$result_date;
						$data_container[$counter][8]	=	$result_time;
						$counter++;
					}
					if(!empty($data_container)){
						return $data_container;
					}else{
						return false;
					}	
				}
			}
		}
		
		function register_app($app_name,$app_contact_no,$app_time,$app_doctor,$app_desc){
			if($stmt_insert = $this->con->prepare("INSERT INTO `appointment_data`(`name`, `contact_no`, `time`, `doctor`, `desc`) VALUES (?,?,?,?,?)")){
				$stmt_insert->bind_param("sssss",$app_name,$app_contact_no,$app_time,$app_doctor,$app_desc);
				if($stmt_insert->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function get_all_app_data(){
			if($stmt_select = $this->con->prepare("SELECT `id`, `name`, `contact_no`, `time`, `doctor`, `desc` FROM `appointment_data`")){	
				$stmt_select->bind_result($result_id,$result_name,$result_number,$result_time,$result_doctor,$result_desc);
				if($stmt_select->execute()){
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch()){
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_name;
						$data_container[$counter][2]	=	$result_number;
						$data_container[$counter][3]	=	$result_time;
						$data_container[$counter][4]	=	$result_doctor;
						$data_container[$counter][5]	=	$result_desc;
						$counter++;
					}
					if(!empty($data_container)){
						return $data_container;
					}else{
						return false;
					}	
				}
			}
		}
		
		function get_patient_data_from_email($result_id){
			if($stmt_select = $this->con->prepare("SELECT `id`, `patient_name`, `patient_email`, `contact_number`, `disease_type`, `patient_age`,`patient_bill` FROM `patient_data` WHERE `id` = ?")){
				$stmt_select->bind_param("s",$result_id);
				$stmt_select->bind_result($result_id,$result_name,$result_email_id,$result_contact_no,$result_diseas_type,$result_patient_age,$result_patient_bill);
				if($stmt_select->execute()){
					$data_container	=	array();
					if($stmt_select->fetch()){
						$data_container[0]	=	$result_id;
						$data_container[1]	=	$result_name;
						$data_container[2]	=	$result_email_id;
						$data_container[3]	=	$result_contact_no;
						$data_container[4]	=	$result_diseas_type;
						$data_container[5]	=	$result_patient_age;
						$data_container[6]	=	$result_patient_bill;
						return $data_container;
					}
				}
				return false;
			}
		}
		
		function register_old_patient($result_id,$result_name,$result_email_id,$result_contact_no,$result_diseas_type,$result_patient_age,$patient_checkup,$result_patient_bill,$p_btn,$patient_extra_checkup,$extra_checkup_fees){
			if($stmt_insert = $this->con->prepare("INSERT INTO `old_patient_database`(`id`,`name`, `email`, `contact_number`, `diseas_type`, `age`, `checkup`,`bill_by_recept`, `precriction`, `additional_checkup`,`total_fees`) VALUES (?,?,?,?,?,?,?,?,?,?,?)")){
				$stmt_insert->bind_param("sssssssssss",$result_id,$result_name,$result_email_id,$result_contact_no,$result_diseas_type,$result_patient_age,$patient_checkup,$result_patient_bill,$p_btn,$patient_extra_checkup,$extra_checkup_fees);
				if($stmt_insert->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function delete_record_of_patient($result_id){
			if($stmt_delete = $this->con->prepare("delete from `patient_data` where `id` = ?")){
				$stmt_delete->bind_param("i",$result_id);
				if($stmt_delete->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function delete_user($d_name){
			if($stmt_delete = $this->con->prepare("delete from `hospital_users` where `name` = ?")){
				$stmt_delete->bind_param("s",$d_name);
				if($stmt_delete->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function delete_app($d_name){
			if($stmt_delete = $this->con->prepare("delete from `appointment_data` where `name` = ?")){
				$stmt_delete->bind_param("s",$d_name);
				if($stmt_delete->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
		function delete_patient($d_name){
			if($stmt_delete = $this->con->prepare("delete from `patient_data` where `patient_name` = ?")){
				$stmt_delete->bind_param("s",$d_name);
				if($stmt_delete->execute()){
					return true;
				}else{
					return false;
				}
			}
		}
		
	}//end class
?>