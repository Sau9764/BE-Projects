<?php
	require_once('lib/db_functions.php');
	$db = new database_functions();
	$flag	=	0;
	$email_error	="";
	$success_msg	=	"";
	$db_password	="";
	if(isset($_POST['submit_btn'])){
		$email_id	=	$_POST['user_email'];
		if($flag==0){
			$user_data	=	array();
			$user_data = $db->get_user_data_from_email($email_id);
			$user_pass	=	"";
			if(!empty($user_data)){
				$user_pass	=	$user_data[7];
			}
			if($user_pass!=""){
				//Send Email
				// EDIT THE 2 LINES BELOW AS REQUIRED
				$email_id = $email_id;
				$email_subject = "Contect us email Form test";
				function died($error) {
					// your error code can go here
					echo "We are very sorry, but there were error(s) found with the form you submitted. ";
					echo "These errors appear below.<br /><br />";
					echo $error."<br /><br />";
					echo "Please go back and fix these errors.<br /><br />";
					die();
				}
				$email_message = "Form details below.\n\n";
				function clean_string($string) {
				  $bad = array("content-type","bcc:","to:","cc:","href");
				  return str_replace($bad,"",$string);
				}
				$email_message =	"Dear User, <br /> Your account login credentials are : <br /> Email Id - ".$email_id." <br /> Password - ".$db_password;
			// create email headers
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			'Reply-To: '.$email_id."\r\n" .
			'X-Mailer: PHP/' . phpversion();
				if(@mail($email_id, $email_subject, $email_message, $headers)){
					$success_msg	=	"Your password sent on your email";
				}else{
					$success_msg	=	"Failed";
				}
			}else{
				$email_error	= "This is user is not exist";
			}
		}
	}
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('header.php');
	?>
	<form action="/forget_pass.php" method="post">
	<div class="middle_container" style="background-color:white;">
	<div class="fb_img" style="background-image:url('/images/home_img.png'); background-size:100% 100%;"></div>
		<div class="sign_in" style="height:250px;"><br>
			<center><div class="common_msg">
				<?php
					echo $success_msg;
				?>
			</div></center>
			<center><span class="error_indicator"><?php echo $email_error; ?></span><br></center>
			<div class="text" style="margin-left:30px; margin-bottom:15px;">Enter your Email ID	</div>
				<center><input type="email" name="user_email" class="f_textbox"  required /><br>
				<input type="submit" name="submit_btn" class="submit_btn" value="SUBMIT"  /><br><br>
				<a href="/index.php" class="signin_link">Get Password ? Log In Here..</a>
				</center>
		</div>
	</div>
	<?php
		require_once('footer.php');
	?>
</body>
</html>