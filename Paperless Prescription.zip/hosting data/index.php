<?php
	require_once('lib/db_functions.php');
	$db = new database_functions();
	if(isset($_SESSION['current_login_user'])){
		header("Location:/doctor/index.php");
		header("Location:/receptionist/index.php");
		header("Location:/admin/index.php");
	}
	if(isset($_GET['logout'])){
		unset($_SESSION['current_login_user']);
	}
	$flag	=	0;
	$password_error	="";
	if(isset($_POST['submit_btn'])){
		$email_id	=	$_POST['user_email'];
		$password	=	$_POST['password'];
		if(strlen($password)<6){
			$password_error	=	"Please enter at least 6 characters in password";
			$flag	=	1;
		}
		if($flag==0){
			$user_data	=	array();
			$user_data = $db->get_user_data_from_email($email_id);
			$user_pass	=	"";
			$user_job	=	"";
			if(!empty($user_data)){
				$user_pass	=	$user_data[7];
				$user_job	=	$user_data[4];
			}
			if($user_pass!=""){
				if($user_pass==$password){
					$_SESSION['current_login_user']	=	$email_id;
					if($user_job=="doctor"){
						header("Location:/doctor/index.php");
					}else if($user_job=="receptionist"){
						header("Location:/receptionist/index.php");
					}else if($user_job=="admin"){
						header("Location:/admin/index.php");
					}
				}else{
					$password_error	= "Incorrect Password";
				}
			}else{
				$password_error	= "This is user is not exist";
			}
		}
	}
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
	<link rel="icon" href="/favicon.ico" type="image/x-icon"/>
	<style type="text/css">
	input[type=text], input[type=password] 
	{
					width: 100%;
					padding: 12px 20px;
					margin: 8px 0;
					display: inline-block;
					border: 1px solid #ccc;
					box-sizing: border-box;
				}
				button {
					background-color: #508abb;
					color: white;
					padding: 14px 20px;
					margin: 8px 0;
					border: none;
					cursor: pointer;
					width: 100%;
				}
				
				button:hover 
				{
					opacity: 0.8;
				}
	</style>
</head>
<body>
		
	<?php
		require_once('header.php');
	?>
	<div class="middle_container" style="background-image:url('/images/home1.jpg'); background-size:100% 100%;">
		<div class="home_img" style="background-image:url('/images/home_img1.jpg'); background-size:100% 100%;"></div>
				<div class="headerlog"><h2>Login Form</h2></div>
				<button onclick="document.getElementById('id01').style.display='block'" style="width:auto; margin-top:200px; margin-left:50px;">Login</button>
				<div id="id01" class="modal">
				  <form class="modal-content animate" action="/index.php" method="post">
					<div class="imgcontainer">
					  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
					  <img src="/images/dp.jpg" alt="Avatar" class="avatar">
					</div>
					<div class="container">
						<center>
							<span class="error_indicator">
								<?php echo $password_error; ?>
							</span>
						</center>
					  <label><b>Username</b></label>
					  <input type="text" placeholder="Enter Username" name="user_email" required>
					  <label><b>Password</b></label>
					  <input type="password" placeholder="Enter Password" name="password" required>
					  <button type="submit" name="submit_btn">Login</button>
					  <input type="checkbox" checked="checked"> Remember me
					</div>
					<div class="container" style="background-color:#f1f1f1">
					  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
					  <span class="psw" style="text-decoration:none;"> <a href="/forget_pass.php">Forgot password?</a></span>
					</div>
				  </form>
				</div>
				<script>
					// Get the modal
					var modal = document.getElementById('id01');

					// When the user clicks anywhere outside of the modal, close it
					window.onclick = function(event) {
						if (event.target == modal) {
							modal.style.display = "none";
						}
					}
				</script>
					<br><br>
					<div class="">
						<a href="/contact-us.php" class="logout_btn" value="CONTACT US" style="float:right; margin:50px;">CONTACT US</a>
						<a href="/about_us.php" class="logout_btn" value="ABOUT US" style="float:right; margin-right:50px; margin-top:50px;">ABOUT US</a>
					</div>

	</div>
		<marquee>Shop no. 20, 31, Vaishnavi plaza,
		near D mart, Jule Solapur-413004 Ph. no.<b>&nbsp 9673114309</b></marquee>		
	<?php
		require_once('footer.php');
	?>
</body>
</html>