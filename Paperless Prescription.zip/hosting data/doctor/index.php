<?php
	require_once('../lib/db_functions.php');
	$db = new database_functions();
	if(!isset($_SESSION['current_login_user'])){
		header("Location:/index.php");
	}
	$email_id	=	$_SESSION['current_login_user'];
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($email_id);
	$user_job	=	"admin";
	$count			=	$db->get_admin_count($user_job);
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
			<br>
				<div class="text" style="margin-left:30px; font-size:20px;">
					Appointments And Patient Details<br>
				</div>
			<br>
				<?php
							require_once('../doctor/app_list.php');	
				?>
				<h1>List Of All Patients.</h1>
				<br>
				<table class="data-table">
					<thead>
						<tr>
							<th>ID</th>
							<th>NAME</th>
							<th>EMAIL</th>
							<th>CONTACT NO.</th>
							<th>DISES TYPE</th>
							<th>AGE</th>
							<th>BILL</th>
							<th>Button</th>
						</tr>
					</thead>
					<?php
						$patient_details	=	array();
						$patient_details	=	$db->get_all_patient_data();
						if(!empty($patient_details)){
							$counter = 0;
							foreach($patient_details as $record){
								$result_id				=	$patient_details[$counter][0];
								$result_patient_name	=	$patient_details[$counter][1];
								$result_patient_email	=	$patient_details[$counter][2];
								$result_contact_number	=	$patient_details[$counter][3];
								$result_disease_type	=	$patient_details[$counter][4];
								$result_patient_age		=	$patient_details[$counter][5];
								$result_patient_bill	=	$patient_details[$counter][6];
								$result_date			=	$patient_details[$counter][7];
								$result_time			=	$patient_details[$counter][8];
								?>										
									<tr>
										<?php
											echo "&nbsp &nbsp<td>".$result_id."<td>&nbsp &nbsp<b>".$result_patient_name."</b>&nbsp &nbsp<td>".$result_patient_email."&nbsp &nbsp<td>".$result_contact_number."&nbsp &nbsp<td>".$result_disease_type."&nbsp &nbsp<td>".$result_patient_age."&nbsp &nbsp<td>".$result_patient_bill;
										?>
										<td><a href="/doctor/details.php?$result_id=<?php echo $result_id; ?>">
											click
										</a>
									</tr>
									<?php					
								$counter++;
							}
						}
					?>
				</table>
		</div>
				<?php
					require_once('../left_panel.php');
					require_once('../footer.php');
				?>	
</body>
</html>