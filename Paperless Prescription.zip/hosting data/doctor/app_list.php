<?php
$con = mysqli_connect("localhost","root","","paperless_precreption");
if (!$con) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
$sql = 'SELECT * 
		FROM appointment_data';
$query = mysqli_query($con, $sql);
if (!$query) {
	die ('SQL Error: ' . mysqli_error($con));
}
?>
<html>
<head>
	<title>Appointment data</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.1/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<h1>List Of All Appoiments.</h1>
	<br>
	<table class="data-table">
		<thead>
			<tr>
				<th>ID</th>
				<th>NAME</th>
				<th>CONTACT NUMBER</th>
				<th>TIME</th>
				<th>DOCTOR</th>
				<th>DESCRIPTION</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		while ($row = mysqli_fetch_array($query)){
			echo '<tr>
					<td>'.$row['id'].'</td>
					<td>'.$row['name'].'</td>
					<td>'.$row['contact_no'].'</td>
					<td>'.$row['time'].'</td>
					<td>'.$row['doctor'].'</td>
					<td>'.$row['desc'].'</td>
				</tr>';
			$no++;
		}?>
		</tbody>
	</table>
</body>
</html>