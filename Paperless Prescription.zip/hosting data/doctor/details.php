<?php
	require_once('../lib/db_functions.php');
	$db = new database_functions();
	if(!isset($_SESSION['current_login_user'])){
		header("Location:/index.php");
	}
	$email_id	=	$_SESSION['current_login_user'];
	$result_id="";
	if(isset($_GET['$result_id'])){
		$result_id	=	$_GET['$result_id'];
	}
	$user_data		=	array();
	$user_data		=	$db->get_patient_data_from_email($result_id);
	$result_id				=	"";
	$result_name			=	"";
	$result_email_id		=	"";
	$result_contact_no		=	"";
	$result_diseas_type		=	"";
	$result_patient_age		=	"";
	$result_patient_bill	=	"";
	$common_msg				=	"";
	if(!empty($user_data)){	
			$result_id				=	$user_data[0];
			$result_name			=	$user_data[1];
			$result_email_id		=	$user_data[2];
			$result_contact_no		=	$user_data[3];
			$result_diseas_type		=	$user_data[4];
			$result_patient_age		=	$user_data[5];
			$result_patient_bill	=	$user_data[6];
		}
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($email_id);
	$flag=0;
	if(isset($_POST['proceed_btn'])){
		$patient_checkup			=	$_POST['patient_checkup'];
		$p_btn						=	$_POST['p_btn'];
		$patient_extra_checkup		=	$_POST['patient_extra_checkup'];
		$extra_checkup_fees			=	$_POST['extra_checkup_fees'];
		if($extra_checkup_fees<=0){
			$fees_error		=	"enter the right fees";
		}
		if($flag==0){
			if($db->register_old_patient($result_id,$result_name,$result_email_id,$result_contact_no,$result_diseas_type,$result_patient_age,$patient_checkup,$result_patient_bill,$p_btn,$patient_extra_checkup,$extra_checkup_fees)){
				$db->delete_record_of_patient($result_id);
				$common_msg	= "Registration successful";
			}else{
				$common_msg	= "Failed";
			}
		}
	}
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
		<?php
			echo $common_msg;
		?>
		<div class="doc_entry">
			<div class="text" style="margin-top:30px;">Patient Name:<br></div>
			<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;" value="<?php echo $result_name; ?>" readonly />
			<div class="text">Patient Email-id:<br></div>
			<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;"value="<?php echo $result_email_id; ?>" readonly />
			<div class="text" >Patient Contact Number:<br></div>
			<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;"value="<?php echo $result_contact_no; ?>" readonly />
			<div class="text" >Patient Disease:<br></div>
			<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;"value="<?php echo $result_diseas_type; ?>"  />
			<div class="text" >Patient Age:<br></div>
			<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;"value="<?php echo $result_patient_age; ?>" readonly />
		</div>
		<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
			<div class="doc_entry1">
				<div class="text" style="margin-top:30px;">Enter Extra Checkup Details:<br></div>
				<input type="text" name="patient_checkup" class="f_textbox" style="margin-top:3px;" />
				<div class="text">Enter Precreption:<br></div>
				<textarea name="p_btn" rows="7" cols="30"   value="Precreption" style="cursor:pointer;"/></textarea>
				<?php
				//<a href="/doctor/voice-text.php"><input type="text" name="p_btn" class="f_textbox" value="Precreption" style="cursor:pointer;"/></a>
				?>
				<br>
				<div class="text">Enter Extra Additional Checkup:<br></div>
				<input type="text" name="patient_extra_checkup" class="f_textbox" style="margin-top:3px;" />
				<br>				
				<div class="text">Enter Extra Fees For Additional Checkup:<br></div>
				<input type="text" name="extra_checkup_fees" class="f_textbox" style="margin-top:3px;" />
				<br>
				<input type="submit" name="proceed_btn" class="proceed_btn" value="SUBMIT" style="margin-left:80px;"/></a>
			</div>
		</form>
		</div>
		<?php
				require_once('../left_panel.php');
		?>		
	</div>
	<?php
		require_once('../footer.php');
	?>
</body>
</html>