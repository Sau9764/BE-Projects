<?php
	require_once('../lib/db_functions.php');
	$db = new database_functions();
	if(!isset($_SESSION['current_login_user'])){
		header("Location:/index.php");
	}
	$email_id	=	$_SESSION['current_login_user'];
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($email_id);
?>
<html lang="en">
<head>
<meta charset="UTF-8">
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
		<br>
	</div>
		<div class="work_area">
			<div class="working_area">
				<a href="/admin/add_member.php" class="admin_features">Add Members</a>
				<br>
				<a href="/admin/doc_list.php" class="admin_features">Doctor</a>
				<br>
				<a href="/admin/recept_list.php" class="admin_features">Receptionist</a>
				<br>
				<a href="/admin/app_list.php" class="admin_features">Appoiments</a>
				<br>
				<a href="/admin/patients_lists.php" class="admin_features">Patients</a>
				<br>
				<a href="/admin/pay_bill.php" class="admin_features">Bill Pay</a>
				<br>
				<form class="form-inline" method="post" action="a.php">
					<button type="submit" id="pdf" name="generate_pdf" class="admin_features">
					Generate PDF</button>
				</form>
				</fieldset>
			</div>
		</div>
		<?php
				require_once('../left_panel.php');
		?>		
	<?php
		require_once('../footer.php');
	?>
</body>
</html>