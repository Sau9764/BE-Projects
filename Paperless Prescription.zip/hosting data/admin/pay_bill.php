<?php
$con = mysqli_connect("localhost","root","","paperless_precreption");
if (!$con) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
$sql = 'SELECT `patient_name`,`patient_bill` FROM patient_data';
$query = mysqli_query($con, $sql);
if (!$query) {
	die ('SQL Error: ' . mysqli_error($con));
}
	require_once('../lib/db_functions.php');
	$db = new database_functions();
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
			<h1>Bill Pay By Patient</h1>
			<div class="bill">
				<a href="/admin/pay_bill_to_recept.php" class="admin_features" style="width:250px;">The Bill Pay To Receptionist.</a>
				<br>
				<a href="/admin/total_bill_pay.php" class="admin_features" style="width:250px;">Total Bill Pay By Patient.</a>
				<br>
			</div>
		</div>
	<?php
				require_once('../left_panel.php');
		?>	
		<?php
			require_once('../footer.php');
		?>
</body>
</html>