<?php
	$common_msg			="";
	$d_name				="";
	
	if(isset($_POST['name']))
	{
		$d_name		=	$_POST['name'];
	}
	
	
	if(isset($_POST['delete_btn']))
	{
		if($d_name!="")
			{
				if($db->delete_user($d_name))
				{
					$common_msg	= "Registration successful";
				}
				else
				{
					$common_msg	= "Failed";
				}
			}
			else
			{
				$common_msg = "enter name witch want to be deleted";
			}
	}
?>
			<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
				<div class="delete_btn">
					<center>
					<label for="first_name"><b>Eneter Name: &nbsp &nbsp   </b></label>
					<input type="text" name="name" placeholder="Delete....">&nbsp &nbsp
					<button class="btn" name="delete_btn"><i class="fa fa-trash"></i></button>
					&nbsp &nbsp &nbsp &nbsp<?php echo $common_msg; ?>
					</center>
				</div>
			</form>