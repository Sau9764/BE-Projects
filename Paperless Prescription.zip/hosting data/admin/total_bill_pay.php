<?php
$con = mysqli_connect("localhost","root","","paperless_precreption");
if (!$con) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
$sql = 'SELECT `name`,`bill_by_recept`,`total_fees` FROM old_patient_database';
$query = mysqli_query($con, $sql);
if (!$query) {
	die ('SQL Error: ' . mysqli_error($con));
}
	require_once('../lib/db_functions.php');
	$db = new database_functions();
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
	<h1>Bill Pay By Patient</h1>
	<br>
	<table class="data-table">
		<thead>
			<tr>
				<th>Sr. No.</th>
				<th>NAME</th>
				<th>PAYMENT TO RECEPTIONIST</th>
				<th>PAYMENT TO DOCTOR</th>
				<th>TOTAL</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		$totalall=0;
		while ($row = mysqli_fetch_array($query)){
			$total=$row['total_fees']+$row['bill_by_recept'];
			echo '<tr>
					<td>'.$no.'</td>
					<td>'.$row['name'].'</td>
					<td>'.'<b>'.'Rs.'.$row['bill_by_recept'].'</b>'.'</td>
					<td>'.'<b>'.'Rs.'.$row['total_fees'].'</b>'.'</td>
					
					<td>'.'<b>'.'Rs.'.$total.'</b>'.'</td>
				</tr>';
			$totalall += $total;
			$no++;
		}?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="4">TOTAL</th>
				<th><b>Rs.<?=$totalall?></b></th>
			</tr>
		</tfoot>
	</table>
	</div>
	<?php
				require_once('../left_panel.php');
		?>	
		<?php
			require_once('../footer.php');
		?>
</body>
</html>