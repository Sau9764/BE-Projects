<?php
$con = mysqli_connect("localhost","root","","paperless_precreption");
if (!$con) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
$user_job="doctor";
$sql = 'SELECT * 
		FROM hospital_users WHERE `user_job` ="doctor"';
$query = mysqli_query($con, $sql);
if (!$query) {
	die ('SQL Error: ' . mysqli_error($con));
}
	require_once('../lib/db_functions.php');
	$db = new database_functions();
?>
<html>
<head>
	<title>PAPERLESS PRECREPTION</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.1/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
	<?php
		require_once('../header.php');
	?>
	<div class="middle_container">
		<?php
			require_once('../common_files/count_page.php');
		?>
	</div>
		<div class="work_area">
			<?php
			require_once('delete_file.php');
		?>
	<h1>List Of All Doctors.</h1>
	<br>
	<table class="data-table">
		
		<thead>
			<tr>
				<th>ID</th>
				<th>NAME</th>
				<th>EMAIL</th>
				<th>CONTACT NUMBER</th>
				<th>USER JOB</th>
				<th>GENDER</th>
				<th>DOB</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		while ($row = mysqli_fetch_array($query)){
			echo '<tr>
					<td>'.$row['id'].'</td>
					<td>'.$row['name'].'</td>
					<td>'.$row['email_id'].'</td>
					<td>'.$row['contact_no'].'</td>
					<td>'.$row['user_job'].'</td>
					<td>'.$row['gender'].'</td>
					<td>'.$row['dob'].'</td>
				</tr>';
			$no++;
		}
		?>
		</tbody>
	</table>
	</div>
		<?php
				require_once('../left_panel.php');
		?>	
		<?php
			require_once('../footer.php');
		?>
</body>
</html>