		<?php
		
			if(!isset($_SESSION['current_login_user']))
			{
				header("Location:/index.php");
			}
			
			$email_id	=	$_SESSION['current_login_user'];
			
			$user_data		=	array();
			$user_data		=	$db->get_user_data_from_email($email_id);
			
			$current_user_name	=	"";
			if(!empty($user_data))
			{
				$current_user_name	=	$user_data[1];
			}	
			
		$path = "../profile-images/";

		$valid_formats = array("jpg", "png", "gif", "bmp", "JPG", "PNG", "GIF", "BMP");
	
			
		if(isset($_POST['slider_images']) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['slider_images']['name'];
			$size 				= 	$_FILES['slider_images']['size'];
		
			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
							$files	=	array();
													
							function generateRandomString($length = 10) {
								$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
								$charactersLength = strlen($characters);
								$randomString = '';
								for ($i = 0; $i < $length; $i++) {
									$randomString .= $characters[rand(0, $charactersLength - 1)];
								}
								
								return $randomString;
							}
							
							$current_random_no =  generateRandomString();
							
							$actual_image_name = $current_random_no.".".strtolower($ext);
							
							$tmp = $_FILES['slider_images']['tmp_name'];
							
							if(move_uploaded_file($tmp, $path.$actual_image_name))
							{
								//Add
								if($db->update_profile_image($actual_image_name,$email_id))
								{
								}
								else
								{
									$common_msg	=	"Failed";
								}
								
								$success_msg = 1;
							}
							else
							{
								$error_message = "failed";
							}
						
					}
					else
					{
						$error_message = "Invalid file format.";	
					}
				}
			else
			{
				$error_message = "Please select image..!";
			}
		}
		?>
		<script type="text/javascript" src="/js/jquery.min.js"></script>
		<script type="text/javascript" src="/js/jquery-1.10.2.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$("#selected_file").change(function(){
					$("#profile_img_update_frm").submit();
				});
			});
		</script>
		<div class="left_panel">
			
			<center>
			<?php 	
			$prof_img	=	$db->get_user_profile_image($email_id);
			
			if($prof_img!="")
			{
			?>
				<img src="/profile-images/<?php echo $prof_img; ?>" class="profile_img" />
			<?php
			}
			else{
			?>
				<img src="/images/default.jpg" class="profile_img" />
			<?php
			}
			?>
			<br>
			<span class="profile_name"><?php echo $current_user_name; ?></span>
			<br />
			<form action="<?php $_SERVER['PHP_SELF']; ?>" id="profile_img_update_frm" method="post" enctype="multipart/form-data">
				<input type="file" id="selected_file" name="slider_images" class="logout_btn" style="width:200px;" />
			</form>
			</center>
			<br />
			<?php
				
					
					if($user_data[4]=="doctor")
					{
			?>
						<a href="/doctor/index.php" class="left_menu">Dashboard</a>
						
			<?php
					}
					else if($user_data[4]=="receptionist")
					{
			?>
						<a href="/receptionist/index.php" class="left_menu">Dashboard</a>
						
			<?php
					}
					else if($user_data[4]=="admin")
					{
			?>
						<a href="/admin/index.php" class="left_menu">Dashboard</a>
						
			<?php
					}
			?>
			<a href="/myprofile.php" class="left_menu">My Profile</a>
			<a href="/common_files/patients_lists.php" class="left_menu">patients</a>
			<a href="/common_files/doc_list.php" class="left_menu">doctors</a>
			<a href="/common_files/recept_list.php" class="left_menu">receptionists</a>
			<a href="/change_pass.php" class="left_menu">change password</a>
			<a href="/index.php?logout" class="left_menu">Logout</a>
			<br /><br />
		</div>