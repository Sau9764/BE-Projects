-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2018 at 05:31 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `paperless_precreption`
--
CREATE DATABASE IF NOT EXISTS `paperless_precreption` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `paperless_precreption`;

-- --------------------------------------------------------

--
-- Table structure for table `appointment_data`
--

CREATE TABLE IF NOT EXISTS `appointment_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `contact_no` text NOT NULL,
  `time` text NOT NULL,
  `doctor` text NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `appointment_data`
--

INSERT INTO `appointment_data` (`id`, `name`, `contact_no`, `time`, `doctor`, `desc`) VALUES
(1, 'appointment1', '9865321470', '9.00 Am', 'Doctor1', 'for meeting'),
(2, 'appointment2', '9865321470', '10.00 Am', 'Doctor1', 'financial report'),
(3, 'appointment3', '9865321470', '11.00 Am', 'Doctor1', 'checkup');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_users`
--

CREATE TABLE IF NOT EXISTS `hospital_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email_id` text NOT NULL,
  `contact_no` text NOT NULL,
  `user_job` text NOT NULL,
  `gender` text NOT NULL,
  `dob` date NOT NULL,
  `password` text NOT NULL,
  `profile_image` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hospital_users`
--

INSERT INTO `hospital_users` (`id`, `name`, `email_id`, `contact_no`, `user_job`, `gender`, `dob`, `password`, `profile_image`, `date`, `time`) VALUES
(1, 'Admin 1', 'a@gmail.com', '8484052559', 'admin', 'Male', '0000-00-00', '123456', 'aH1jwqqo5f.jpg', '0000-00-00', ''),
(2, 'Doctor1', 'd@gmail.com', '8484052559', 'doctor', 'male', '2017-08-16', '123456', 'LGoUFAjk2m.jpg', '2017-07-12', ''),
(3, 'receptionist 1', 'r@gmail.com', '8484052559', 'receptionist', 'male', '2017-11-21', '123456', 'ffQDU0ysxq.jpg', '2017-11-01', '');

-- --------------------------------------------------------

--
-- Table structure for table `old_patient_database`
--

CREATE TABLE IF NOT EXISTS `old_patient_database` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `contact_number` text NOT NULL,
  `diseas_type` text NOT NULL,
  `age` text NOT NULL,
  `checkup` text NOT NULL,
  `bill_by_recept` text NOT NULL,
  `precriction` text NOT NULL,
  `additional_checkup` text NOT NULL,
  `total_fees` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `old_patient_database`
--

INSERT INTO `old_patient_database` (`id`, `name`, `email`, `contact_number`, `diseas_type`, `age`, `checkup`, `bill_by_recept`, `precriction`, `additional_checkup`, `total_fees`) VALUES
(1, 'nikhil koli', 'nk@gmail.com', '9876543210', '2', '52', '-', '200', 'tab1 1-1-1\r\ntab2 1-1', 'no', '50');

-- --------------------------------------------------------

--
-- Table structure for table `patient_data`
--

CREATE TABLE IF NOT EXISTS `patient_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_name` text NOT NULL,
  `patient_email` text NOT NULL,
  `contact_number` text NOT NULL,
  `disease_type` text NOT NULL,
  `patient_age` text NOT NULL,
  `patient_bill` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `patient_data`
--

INSERT INTO `patient_data` (`id`, `patient_name`, `patient_email`, `contact_number`, `disease_type`, `patient_age`, `patient_bill`, `date`, `time`) VALUES
(2, 'atish pratap', '', '9876542180', '4', '32', '100', '2018-03-13', '02:57:12pm');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
