<?php
	$admin	=	"admin";
	$count_a			=	$db->get_admin_count($admin);
	
	$doctor	=	"doctor";
	$count_d	=	$db->get_doctor_count($doctor);
	
	$receptionist	=	"receptionist";
	$count_r	=	$db->get_receptionist_count($receptionist);
	
	$count_p	=	$db->get_patient_count();
	
	$count_app	=	$db->get_app_count();
	
	
?>


		<div class="dashboard_panel">
			<div class="db_name">
				
				<div class="db_list">
				<center>
				<div class="count">admin<hr><span class="count_no"><?php echo $count_a; ?></span></div>
				<div class="count">receptionists <hr><span class="count_no"><?php echo $count_r; ?></span></div>
				<div class="count">patient <hr><span class="count_no"><?php echo $count_p; ?></span></span></div>
				<div class="count">Appointments<hr><span class="count_no"><?php echo $count_app; ?></span></div>
				<div class="count">doctor<hr><span class="count_no"><?php echo $count_d; ?></span></div>
				
				</center>
				</div>
			</div>
		