<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('header.php');
	?>
	
	<div class="middle_container" style="background-image:url('/images/home-back.jpg'); background-size:100% 100%;">
		<marquee><font size=50><font color="white">
			<b>WELCOME TO INSTAGRAM..</b>
		</font size></marquee>
			
	</div>
	
	<?php
		require_once('footer.php');
	?>
	
</body>
</html>