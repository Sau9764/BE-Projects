<div class="footer">
		<a href="/index.php" class="f_menu">HOME</a>
		<?php
				if(!isset($_SESSION['current_login_user']))
				{
				?>
				<a href="/sign-up.php" class="f_menu">SIGN UP</a>
				<a href="/sign-in.php" class="f_menu">SIGN IN</a>
				<?php
				}
				?>
		<a href="/about-us.php" class="f_menu">ABOUT US</a>
		<a href="/contact-us.php" class="f_menu">CONTACT US</a>
	</div>