<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('header.php');
	?>
	
	<div class="middle_container">
		
		<h1 class="insta_title">ABOUT INSTAGRAM</h1>
		
		<div class="about_data_container">
			<span class="blank"></span>Kevin Systrom (@kevin) is the CEO and co-founder of Instagram, a community of more than 600 million who capture and share the world's moments on the service. He is responsible for the company's overall vision and strategy as well as day-to-day operations.

Since the beginning, Kevin has focused on simplicity and inspiring creativity through solving problems with thoughtful product design. As a result, Instagram has become the home for visual storytelling for everyone from celebrities, newsrooms and brands, to teens, musicians and anyone with a creative passion.<br />

<span class="blank"></span>Prior to founding Instagram, Kevin was part of the startup Odeo, which later became Twitter, and spent two years at Google working on products like Gmail and Google Reader. He graduated from Stanford University with a BS in Management Science & Engineering and serves on the boards of Walmart and KCRW.

Mike Krieger (@mikeyk) is the CTO and co-founder of Instagram, a global community of more than 600 million. As the head of engineering, Mike focuses on building products that bring out the creativity in all of us.

A native of São Paulo, Brazil, Mike holds an MS in Symbolic Systems from Stanford University. Prior to founding Instagram, he worked at Meebo as a user experience designer and front-end engineer.
		</div>
		
	</div>
	
	<?php
		require_once('footer.php');
	?>
	
</body>
</html>