<div class="header">
		<div class="subheader">
			<a href="/" class="web_title">
			<img src="/images/icon.png" class="icon_img">
			<span class="">INSTAGRAM APPLICATION</a>
			
			<div class="menubar">
				<a href="/index.php" class="menu">HOME</a>
				
				
				<?php
				if(!isset($_SESSION['current_login_user']))
				{
				?>
				<a href="/sign-up.php" class="menu">SIGN UP</a>
				<a href="/sign-in.php" class="menu">SIGN IN</a>
				<?php
				}
				?>
				<a href="/about-us.php" class="menu">ABOUT US</a>
				<a href="/contact-us.php" class="menu">CONTACT US</a>
			</div>
		</div>
	</div>