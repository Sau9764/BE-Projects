<?php
	session_start();
	
	date_default_timezone_set("Asia/kolkata");
	
	class database_functions
	{
		private $con;
		
		function __construct()
		{
			$this->con	=	new mysqli("localhost","root","","instagram_application");
		}
		
		function register_user($user_name,$user_email,$user_contact_no,$user_gender,$user_dob,$user_password)
		{
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `application_users`(`name`, `email_id`, `contact_no`, `gender`, `dob`, `password`, `date`, `time`) VALUES (?,?,?,?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("ssssssss",$user_name,$user_email,$user_contact_no,$user_gender,$user_dob,$user_password,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function get_user_exist_value($user_email)
		{
			if($stmt_select = $this->con->prepare("Select `id` from `application_users` where `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$user_email);
				
				$stmt_select->bind_result($result_id);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		
		function get_user_password($email_id)
		{
			if($stmt_select = $this->con->prepare("Select `password` from `application_users` where `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$email_id);
				
				$stmt_select->bind_result($result_password);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_password;
					}
				}
				return false;
			}		
		}
		
		function get_user_data_from_email($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `name`, `email_id`, `contact_no`, `gender`, `dob`, `password`, `date`, `time` FROM `application_users` WHERE `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_id,$result_name,$result_email_id,$result_contact_no,$result_gender,$result_dob,$result_password,$result_date,$result_time);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					
					if($stmt_select->fetch())
					{
						$data_container[0]	=	$result_id;
						$data_container[1]	=	$result_name;
						$data_container[2]	=	$result_email_id;
						$data_container[3]	=	$result_contact_no;
						$data_container[4]	=	$result_gender;
						$data_container[5]	=	$result_dob;
						$data_container[6]	=	$result_password;
						$data_container[7]	=	$result_date;
						$data_container[8]	=	$result_time;
						
						return $data_container;
					}
				}
				return false;
			}
		}
		function update_user($user_name,$user_contact_no,$user_gender,$user_dob,$user_email)
		{
			
			if($stmt_update = $this->con->prepare("UPDATE `application_users` SET `name`=?,`contact_no`=?,`gender`=?,`dob`=? WHERE `email_id` = ?"))
			{
				$stmt_update->bind_param("sssss",$user_name,$user_contact_no,$user_gender,$user_dob,$user_email);
				
				if($stmt_update->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function update_user_password($login_email,$new_pwd)
		{
			if($stmt_update = $this->con->prepare("UPDATE `application_users` SET `password`=? WHERE `email_id` = ?"))
		
			$stmt_update->bind_param("ss",$new_pwd,$login_email);
			
			if($stmt_update->execute())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		function check_category_exist($category_name)
		{
			if($stmt_select = $this->con->prepare("Select `id` from `insta_groups` where `group_name` = ?"))
			{
				$stmt_select->bind_param("s",$category_name);
				
				$stmt_select->bind_result($result_id);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		function create_new_group($category_name,$actual_image_name,$login_email)
		{
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			$profile_img_name	=	$actual_image_name;
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `insta_groups`(`created_by`, `group_name`, `profile_img`, `date`, `time`) VALUES (?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("sssss",$login_email,$category_name,$profile_img_name,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function get_my_all_categories($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `created_by`, `group_name`, `profile_img`, `date`, `time` FROM `insta_groups` WHERE `created_by` = ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_id,$result_created_by,$result_group_name,$result_profile_img,$result_date,$result_time);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_created_by;
						$data_container[$counter][2]	=	$result_group_name;
						$data_container[$counter][3]	=	$result_profile_img;
						$data_container[$counter][4]	=	$result_date;
						$data_container[$counter][5]	=	$result_time;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function delete_category_record($delete_id)
		{
			if($stmt_delete = $this->con->prepare("delete from `insta_groups` where `id` = ?"))
			{
				$stmt_delete->bind_param("i",$delete_id);
				
				if($stmt_delete->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		function get_all_categories($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `created_by`, `group_name`, `profile_img`, `date`, `time` FROM `insta_groups` WHERE `created_by` != ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_id,$result_created_by,$result_group_name,$result_profile_img,$result_date,$result_time);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$result_created_by;
						$data_container[$counter][2]	=	$result_group_name;
						$data_container[$counter][3]	=	$result_profile_img;
						$data_container[$counter][4]	=	$result_date;
						$data_container[$counter][5]	=	$result_time;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function follow_category($result_id,$login_email)
		{
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `follow_groups`( `category_id`, `followed_by`, `date`, `time`) VALUES (?,?,?,?)"))
			{
				$stmt_insert->bind_param("ssss",$result_id,$login_email,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		function check_user_follow_exist($login_email,$result_id)
		{
			if($stmt_select = $this->con->prepare("Select `id` from `follow_groups` where `followed_by` = ? AND `category_id` = ?"))
			{
				$stmt_select->bind_param("ss",$login_email,$result_id);
				
				$stmt_select->bind_result($result_id);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		function unfollow_category($result_id,$login_email)
		{
			if($stmt_delete = $this->con->prepare("delete from `follow_groups` where `category_id` = ? AND `followed_by` = ?"))
			{
				$stmt_delete->bind_param("ss",$result_id,$login_email);
				
				if($stmt_delete->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function get_all_my_following_groups($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `category_id` FROM `follow_groups` WHERE `followed_by` = ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_cat_id);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter]	=	$result_cat_id;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function get_all_my_groups_id($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `id` FROM `insta_groups` WHERE `created_by` = ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_cat_id);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter]	=	$result_cat_id;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function get_category_data_from_id($current_category_id)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `created_by`, `group_name`, `profile_img` FROM `insta_groups` WHERE `id` = ?"))
			{
				$stmt_select->bind_param("i",$current_category_id);
				
				$stmt_select->bind_result($result_cat_id,$result_created_by,$result_group_name,$result_profile_img);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();

					if($stmt_select->fetch())
					{
						$data_container[0]	=	$result_cat_id;
						$data_container[1]	=	$result_created_by;
						$data_container[2]	=	$result_group_name;
						$data_container[3]	=	$result_profile_img;
						
						return $data_container;
					}
					return false;
				}
			}
		}
		
		function get_all_followers($cat_id)
		{
			if($stmt_select = $this->con->prepare("SELECT `followed_by` FROM `follow_groups` WHERE `category_id` = ?"))
			{
				$stmt_select->bind_param("s",$cat_id);
				
				$stmt_select->bind_result($result_followed_by);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter]	=	$result_followed_by;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function upload_my_post($group_id,$actual_image_name,$login_email)
		{
			$date	=	date("Y-m-d");
			$time	=	date("h:i:sa");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `user_posts`(`group_id`,`image_name`, `posted_by`, `date`, `time`) VALUES (?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("sssss",$group_id,$actual_image_name,$login_email,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function get_all_users_post_data()
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `posted_by`, `date`, `time`,`group_id` FROM `user_posts` ORDER BY `id` DESC"))
			{	
				$stmt_select->bind_result($result_id,$image_name,$posted_by,$date,$time,$group_id);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$image_name;
						$data_container[$counter][2]	=	$posted_by;
						$data_container[$counter][3]	=	$date;
						$data_container[$counter][4]	=	$time;
						$data_container[$counter][5]	=	$group_id;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}	
				}
			}
		}
		
		function get_all_users_post_data_from_email($current_login_user)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `posted_by`, `date`, `time` FROM `user_posts` where `posted_by` = ? ORDER BY `id` DESC"))
			{	
				$stmt_select->bind_param("s",$current_login_user);
				
				$stmt_select->bind_result($result_id,$image_name,$posted_by,$date,$time);
				
				if($stmt_select->execute())
				{
					$data_container	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$data_container[$counter][0]	=	$result_id;
						$data_container[$counter][1]	=	$image_name;
						$data_container[$counter][2]	=	$posted_by;
						$data_container[$counter][3]	=	$date;
						$data_container[$counter][4]	=	$time;
						
						$counter++;
					}
					if(!empty($data_container))
					{
						return $data_container;
					}
					else
					{
						return false;
					}	
				}
			}
		}
		
		function update_profile_image($actual_image_name,$login_email)
		{
			if($stmt_update = $this->con->prepare("UPDATE `application_users` SET `profile_image`=? WHERE `email_id` = ?"))
			{
				$stmt_update->bind_param("ss",$actual_image_name,$login_email);
				
				if($stmt_update->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
	
		function get_user_profile_image($login_email)
		{
			if($stmt_select = $this->con->prepare("SELECT `profile_image` FROM `application_users` WHERE `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$login_email);
				
				$stmt_select->bind_result($result_profile_img);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_profile_img;
					}
					return false;
				}
			}
		}
		
		function check_user_followed_to_this_group($group_id,$login_email)
		{
			if($stmt_select = $this->con->prepare("Select `id` from `follow_groups` where `category_id` = ? AND `followed_by` = ?"))
			{
				$stmt_select->bind_param("ss",$group_id,$login_email);
				
				$stmt_select->bind_result($result_id);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_id;
					}
				}
				return false;
			}		
		}
		
		function check_user_is_owener_of_group($group_id,$login_email)
		{
			if($stmt_select = $this->con->prepare("Select `id` from `insta_groups` where `id` = ? AND `created_by` = ?"))
			{
				$stmt_select->bind_param("ss",$group_id,$login_email);
				
				$stmt_select->bind_result($result_id);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_id;
					}
				}
				return false;
			}	
		}
		
	}//end class
?>