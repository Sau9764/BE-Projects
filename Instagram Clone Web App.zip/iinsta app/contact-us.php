<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('header.php');
	?>
	
	<div class="middle_container">
		<iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d2477.419527003413!2d75.91835080444503!3d17.637640081288716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3bc5da1ed3381eed%3A0x6fdb8e3ff8ffd70c!2sdream+technology+solapur!3m2!1d17.637750999999998!2d75.919766!5e1!3m2!1sen!2sin!4v1496147547585" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
	
	<?php
		require_once('footer.php');
	?>
	
</body>
</html>