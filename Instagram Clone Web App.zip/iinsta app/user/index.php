<?php
	require_once('../lib/db_functions.php');
	
	$db = new database_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/sign-in.php");
	}
	
	$login_email	=	$_SESSION['current_login_user'];
	
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($login_email);
	
	$current_user_name	=	"";
	
	if(!empty($user_data))
	{
		$current_user_name	=	$user_data[1];
	}
	
	$common_msg	=	"";
	
	if(isset($_POST['submit_btn']))
	{	
		/*
		Image Upload
		*/
		
		$path = "../posts/";

		$valid_formats = array("jpg", "png", "gif", "bmp", "JPG", "PNG", "GIF", "BMP");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['slider_images']['name'];
			$size 				= 	$_FILES['slider_images']['size'];
			
			$group_id			=	$_POST['group_id'];
		
			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
							$files	=	array();
													
							function generateRandomString_a($length = 10) {
								$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
								$charactersLength = strlen($characters);
								$randomString = '';
								for ($i = 0; $i < $length; $i++) {
									$randomString .= $characters[rand(0, $charactersLength - 1)];
								}
								
								return $randomString;
							}
							
							$current_random_no =  generateRandomString_a();
							
							$actual_image_name = $current_random_no.".".strtolower($ext);
							
							$tmp = $_FILES['slider_images']['tmp_name'];
							
							if(move_uploaded_file($tmp, $path.$actual_image_name))
							{
								//Add
								if($db->upload_my_post($group_id,$actual_image_name,$login_email))
								{
									$common_msg	=	" Your Post Uploaded Successfully";
								}
								else
								{
									$common_msg	=	"Failed";
								}
								
								$success_msg = 1;
							}
							else
							{
								$error_message = "failed";
							}
						
					}
					else
					{
						$error_message = "Invalid file format.";	
					}
				}
			else
			{
				$error_message = "Please select image..!";
			}
		}
	}
?>
	
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('../header.php');
	?>
	
	<div class="middle_container">
			
		<?php
			require_once('left-panel.php');
		?>		
			
		<div style="float:none; margin-left:250px; display:inline-table; width:800px; text-align:center; padding-top:-150px;">
				<?php
					if($common_msg!="")
					{
				?>
				<div class="common_msg">
					<?php
						echo $common_msg;
					?>
				</div>
				<?php
					}
				?>
				
			<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">					
			
				<select class="f_textbox" name="group_id" style="width:200px;">
				<?php
					$groups_data	=	array();
					$groups_data	=	$db->get_my_all_categories($login_email);
					
					if(!empty($groups_data))
					{
						$counter = 0;
						foreach($groups_data as $record)
						{
							$result_id			=	$groups_data[$counter][0];
							$result_created_by	=	$groups_data[$counter][1];
							$result_group_name	=	$groups_data[$counter][2];
							$result_profile_img	=	$groups_data[$counter][3];
							$result_date		=	$groups_data[$counter][4];
							$result_time		=	$groups_data[$counter][5];
				?>
					<option value="<?php echo $result_id; ?>"><?php echo $result_group_name; ?></option>
				<?php
							$counter++;
						}
					}	
				?>
				</select>
				
				<input type="file" name="slider_images" class="f_textbox" required style="width:300px; margin-left:15px; padding:4px; margin-right:15px;" />
					 
				<input type="submit" name="submit_btn" class="submit_btn" value="UPLOAD MY POST" />	
			</form>	
			<hr />
			
			<?php
				
				$post_data	=	array();
				$post_data	=	$db->get_all_users_post_data();
				
				if(!empty($post_data))
				{	
					$counter = 0;
					
					foreach($post_data as $record)
					{
						$result_id	=	$post_data[$counter][0];
						$image_name	=	$post_data[$counter][1];
						$posted_by	=	$post_data[$counter][2];
						$date		=	$post_data[$counter][3];
						$time		=	$post_data[$counter][4];
						$group_id	=	$post_data[$counter][5];
						
						$chek_followed	=	$db->check_user_followed_to_this_group($group_id,$login_email);
						
						$category_owener=	$db->check_user_is_owener_of_group($group_id,$login_email);
						
						$display_status	=	0;
						if($category_owener!="")
						{
							$display_status	=	1;
						}
						else if($chek_followed!="")
						{
							$display_status	=	1;
						}

						if($display_status==1)
						{
			?>
					<div class="post_container">
						<img src="/posts/<?php echo $image_name; ?>" class="post_img" />
						<?php echo "Posted By ".$posted_by." Date : ".$date." Time : ".$time; ?>
						
					</div>
			<?php
						}
						
						$counter++;
					}
				}
			?>
			
			
		</div>
	</div>
	
	<?php
		require_once('../footer.php');
	?>
	
</body>
</html>