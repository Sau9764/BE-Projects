<?php
	require_once('../lib/db_functions.php');
	
	$db = new database_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/sign-in.php");
	}
	
	$login_email	=	$_SESSION['current_login_user'];
	
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($login_email);
	
	$current_user_name	=	"";
	
	if(!empty($user_data))
	{
		$current_user_name	=	$user_data[1];
	}

?>
	
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('../header.php');
	?>
	
	<div class="middle_container">
			
		<?php
			require_once('left-panel.php');
		?>		
			
		<div style="float:none; display:inline-table; width:800px; text-align:center;">
							
			<?php
				
				$post_data	=	array();
				$post_data	=	$db->get_all_users_post_data_from_email($login_email);
				
				if(!empty($post_data))
				{	
					$counter = 0;
					
					foreach($post_data as $record)
					{
						$result_id	=	$post_data[$counter][0];
						$image_name	=	$post_data[$counter][1];
						$posted_by	=	$post_data[$counter][2];
						$date		=	$post_data[$counter][3];
						$time		=	$post_data[$counter][4];
			?>
					<div class="post_container">
						<img src="/posts/<?php echo $image_name; ?>" class="post_img" />
						<?php echo "Posted By ".$posted_by." Date : ".$date." Time : ".$time; ?>
						
					</div>
			<?php
						$counter++;
					}
				}
			?>
			
			
		</div>
	</div>
	
	<?php
		require_once('../footer.php');
	?>
	
</body>
</html>