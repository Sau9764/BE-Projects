<?php
	require_once('../lib/db_functions.php');
	
	$db = new database_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/sign-in.php");
	}
	
	$login_email	=	$_SESSION['current_login_user'];
	
	$common_msg	=	"";
	$conf_pwd_error	=	"";
	$cur_pwd_error		=	"";
	$new_pwd_error		=	"";
	$flag				=	0;
	
	if(isset($_POST['submit_btn']))	
	{
		$cur_pwd	=	$_POST['current_password'];
		$new_pwd	=	$_POST['new_password'];
		$conf_pwd	=	$_POST['confirm_password'];
		
		if(strlen($cur_pwd)<6)
		{
			$cur_pwd_error		=	"Please enter at least 6 characters";
			$flag				=	1;
		}
		
		if(strlen($new_pwd)<6)
		{
			$new_pwd_error		=	"Please enter at least 6 characters";
			$flag				=	1;
		}
		else if($new_pwd!=$conf_pwd)
		{
			$conf_pwd_error	=	"Please match the password";
			$flag				=	1;
		}
		
		if($flag==0)
		{
			$db_password = $db->get_user_password($login_email);
			
			if($db_password==$cur_pwd)
			{
				//update
				if($db->update_user_password($login_email,$new_pwd))
				{
					$common_msg	=	"Your password has been changed.";
				}
				else{
					$common_msg	=	"Failed";
				}
			}
			else
			{
				$common_msg	=	"Incorrect password";
			}
		}
		
	}
	
?>
	
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('../header.php');
	?>
	
	<div class="middle_container">
	<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
		<div class="inner_form_container">
			
			<div class="common_msg">
				<?php
					echo $common_msg;
				?>
			</div>
			
			<input type="password" name="current_password" class="f_textbox" placeholder="Enter current password" required />
			<span class="error_indicator"><?php echo $cur_pwd_error; ?></span>
			<input type="password" name="new_password" class="f_textbox" placeholder="Enter new password" required />
			<span class="error_indicator"><?php echo $new_pwd_error; ?></span>
			<input type="password" name="confirm_password" class="f_textbox" placeholder="Enter confirm password" required />
			<span class="error_indicator"><?php echo $conf_pwd_error; ?></span>
			
			<center><input type="submit" name="submit_btn" class="submit_btn" value="CHANGE MY PASSWORD" />
				
		</div>
	</form>
	
		<?php
			require_once('left-panel.php');
		?>
	</div>
	
	<?php
		require_once('../footer.php');
	?>
	
</body>
</html>