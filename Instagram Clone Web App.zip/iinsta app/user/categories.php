<?php
	require_once('../lib/db_functions.php');
	
	$db = new database_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/sign-in.php");
	}
	
	$login_email	=	$_SESSION['current_login_user'];
	
	$common_msg	=	"";
	
	if(isset($_GET['delete_id']))
	{
		$delete_id	=	$_GET['delete_id'];
		$img_name	=	$_GET['img_name'];
		
		if(unlink('../gallery-images/'.$img_name))
		{
			if($db->delete_category_record($delete_id))
			{
				$common_msg	=	$delete_id."- category deleted successfully";
			}
			
		}	
	}
	
	
	if(isset($_GET['result_id']) AND isset($_GET['login_email']) AND isset($_GET['unfollow']))
	{
		$result_id	=	$_GET['result_id'];
		$login_email	=	$_GET['login_email'];
		
		if($db->unfollow_category($result_id,$login_email))
		{	
			$common_msg	=	"Category unfollowed successfully..";
		}
		else
		{
			$common_msg	=	"Failed..";
		}
	}
	else if(isset($_GET['result_id']) AND isset($_GET['login_email']) AND isset($_GET['follow']))
	{
		$result_id	=	$_GET['result_id'];
		$login_email	=	$_GET['login_email'];
		
		if($db->follow_category($result_id,$login_email))
		{	
			$common_msg	=	"followed successfully..";
		}
		else
		{
			$common_msg	=	"Failed..";
		}
		
	}
		
	if(isset($_POST['submit_btn']))
	{
		$category_name	=	$_POST['category_name'];
		
		$category_exist	=	"";
		$category_exist	=	$db->check_category_exist($category_name);
		
		if($category_exist=="")
		{
		
		/*
		Image Upload
		*/
		
		$path = "../gallery-images/";

		$valid_formats = array("jpg", "png", "gif", "bmp", "JPG", "PNG", "GIF", "BMP");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['slider_images']['name'];
			$size 				= 	$_FILES['slider_images']['size'];
		
			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
							$files	=	array();
													
							function generateRandomString($length = 10) {
								$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
								$charactersLength = strlen($characters);
								$randomString = '';
								for ($i = 0; $i < $length; $i++) {
									$randomString .= $characters[rand(0, $charactersLength - 1)];
								}
								
								return $randomString;
							}
							
							$current_random_no =  generateRandomString();
							
							$actual_image_name = $current_random_no.".".strtolower($ext);
							
							$tmp = $_FILES['slider_images']['tmp_name'];
							
							if(move_uploaded_file($tmp, $path.$actual_image_name))
							{
								//Add
								if($db->create_new_group($category_name,$actual_image_name,$login_email))
								{
									$common_msg	=	$category_name." Group Created Successfully";
								}
								else
								{
									$common_msg	=	"Failed";
								}
								
								$success_msg = 1;
							}
							else
							{
								$error_message = "failed";
							}
						
					}
					else
					{
						$error_message = "Invalid file format.";	
					}
				}
			else
			{
				$error_message = "Please select image..!";
			}
		}
		
		
			
		}
		else
		{
			$common_msg	=	"This Group Is Already Exist";
		}
	}
?>
	
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('../header.php');
	?>
	
	<div class="middle_container">
	
	<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
		<div class="create_category_container">
				
				<?php
					if($common_msg!="")
					{
				?>
				<div class="common_msg">
					<?php
						echo $common_msg;
					?>
				</div>
				<?php
					}
				?>
				
				<input type="text" name="category_name" class="f_textbox" placeholder="Enter category name" required />
				
				<input type="file" name="slider_images" class="f_textbox" required style="width:200px; margin-left:15px; padding:4px; margin-right:15px;" />
					 
				<input type="submit" name="submit_btn" class="submit_btn" value="CREATE CATEGORY" />	
				
				<hr />
				
			<div class="groups_container">
				<h2><span class="cat_title">MY GROUPS</span><h2>
				
				<?php
					$groups_data	=	array();
					$groups_data	=	$db->get_my_all_categories($login_email);
					
					
					if(!empty($groups_data))
					{
						$counter = 0;
						foreach($groups_data as $record)
						{
							$result_id			=	$groups_data[$counter][0];
							$result_created_by	=	$groups_data[$counter][1];
							$result_group_name	=	$groups_data[$counter][2];
							$result_profile_img	=	$groups_data[$counter][3];
							$result_date		=	$groups_data[$counter][4];
							$result_time		=	$groups_data[$counter][5];
							
							
				?>
				<div class="cat_img_cover">
					<div class="category_img_title"><?php echo $result_group_name; ?></div>
					<img src="/gallery-images/<?php echo $result_profile_img; ?>" class="group_img" />
					<a href="/user/categories.php?delete_id=<?php echo $result_id; ?>&img_name=<?php echo $result_profile_img; ?>" class="cat_del_link">Delete</a>
				</div>	
					
				<?php
							$counter++;
						}
					}
					else
					{
						echo "Yet, You have not created any groups";
					}
				?>
			
				<hr>
				
				<h2><span class="cat_title">OTHER GROUPS</span></h2>
				
				<?php
					$groups_data	=	array();
					$groups_data	=	$db->get_all_categories($login_email);
					
					
					if(!empty($groups_data))
					{
						$counter = 0;
						foreach($groups_data as $record)
						{
							$result_id			=	$groups_data[$counter][0];
							$result_created_by	=	$groups_data[$counter][1];
							$result_group_name	=	$groups_data[$counter][2];
							$result_profile_img	=	$groups_data[$counter][3];
							$result_date		=	$groups_data[$counter][4];
							$result_time		=	$groups_data[$counter][5];
							
							$follow_exist	=	"";
							
							$follow_exist	=	$db->check_user_follow_exist($login_email,$result_id);
												
				?>
				<div class="cat_img_cover" style=width:120px;>
					<div class="category_img_title" style=padding:1px;"><?php echo $result_group_name; ?></div>
					<img src="/gallery-images/<?php echo $result_profile_img; ?>" class="other_group_img" />

					<?php
					if($follow_exist=="")
					{
					?>					
					<a href="/user/categories.php?result_id=<?php echo $result_id; ?>&login_email=<?php echo $login_email; ?>&follow" class="cat_follow_link">Follow</a>
					<?php
					}
					else{
					?>
					<a href="/user/categories.php?result_id=<?php echo $result_id; ?>&login_email=<?php echo $login_email; ?>&unfollow" class="cat_follow_link">Unfollow</a>
					<?php
					}
					?>
				
				</div>	
					
				<?php
							$counter++;
						}
					}
					else
					{
						echo "Yet, You have not created any groups";
					}
				?>
				
			
			</div>
	
		</div>
		
		
	</form>
	
		<?php
			require_once('left-panel.php');
		?>
	</div>
	
	<?php
		require_once('../footer.php');
	?>
	
</body>
</html>