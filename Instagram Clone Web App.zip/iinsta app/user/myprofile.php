<?php
	require_once('../lib/db_functions.php');
	
	$db = new database_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/sign-in.php");
	}
	
	$login_email	=	$_SESSION['current_login_user'];

	$contact_number_error	=	"";
	$gender_error			=	"";
	$password_error			=	"";
	$conf_password_error	=	"";
	$captcha_code_error		=	"";
	$common_msg				=	"";
	
	$flag	=	0;
	
	if(isset($_POST['submit_btn']))
	{
		$user_name		=	$_POST['user_name'];
		$user_email		=	$_POST['user_email'];
		$user_contact_no=	$_POST['contact_number'];
		$user_gender	=	$_POST['user_gender'];
		$user_dob		=	$_POST['dob'];
		
		
		if(!is_numeric($user_contact_no))
		{
			$contact_number_error	=	"Please enter numeric contact number";
			$flag	=	1;
		}
		else if(strlen($user_contact_no)!=10)
		{
			$contact_number_error	=	"Please enter valid 10 digit contact number";	
			$flag	=	1;
		}
		
		if($user_gender=="Select Gender")
		{
			$gender_error	=	"Please select gender";
			$flag	=	1;
		}
		if($flag==0)
		{			 
				if($db->update_user($user_name,$user_contact_no,$user_gender,$user_dob,$user_email))
				{
					$common_msg	= "Update successful";
				}
				else
				{
					$common_msg	= "Failed";
				}
		}
		
	}
	
	$user_data		=	array();
	$user_data		=	$db->get_user_data_from_email($login_email);
			
	$result_id		=	"";
	$result_name	=	"";
	$result_email_id=	"";
	$result_contact_no=	"";
	$result_gender	=	"";
	$result_dob		=	"";
	
	if(!empty($user_data))
	{	
		$result_id		=	$user_data[0];
		$result_name	=	$user_data[1];
		$result_email_id=	$user_data[2];
		$result_contact_no=	$user_data[3];
		$result_gender	=	$user_data[4];
		$result_dob		=	$user_data[5];
	}
	
?>
	
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
</head>
<body>
	
	<?php
		require_once('../header.php');
	?>
	
	<div class="middle_container">
	<form action="/user/myprofile.php" method="post">
		<div class="inner_form_container">
			
			<div class="common_msg">
				<?php
					echo $common_msg;
				?>
			</div>
			
			<input type="text" name="user_name" class="f_textbox" placeholder="Enter your name" required value="<?php echo $result_name; ?>" />
			
			<input type="email" name="user_email" class="f_textbox" placeholder="Enter your email ID" required value="<?php echo $result_email_id; ?>" readonly />
			
			<input type="text" name="contact_number" class="f_textbox" placeholder="Enter Your Contact Number" required value="<?php echo $result_contact_no; ?>" />
			<span class="error_indicator">
				<?php 
					echo $contact_number_error; 
				?>
			</span>
			<select name="user_gender" class="f_textbox">
				<option value="<?php echo $result_gender; ?>"><?php echo $result_gender; ?></option>
				<option value="Select Gender">Select Gender</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
			<span class="error_indicator">
				<?php
					echo $gender_error;
				?>
			</span>
			<input type="text" name="dob" class="f_textbox" placeholder="Enter your DOB" required value="<?php echo $result_dob; ?>" />
			
			<center><input type="submit" name="submit_btn" class="submit_btn" value="UPDATE MY INFO" />
				
		</div>
	</form>
	
		<?php
			require_once('left-panel.php');
		?>
	</div>
	
	<?php
		require_once('../footer.php');
	?>
	
</body>
</html>