<?php
	require_once('lib/db_functions.php');
	
	$db = new database_functions();
	
	if(isset($_SESSION['current_login_user']))
	{
		header("Location:/user/index.php");
	}
	
	if(isset($_GET['logout']))
	{
		unset($_SESSION['current_login_user']);
	}
	
	$flag	=	0;
	$password_error	="";
	
	if(isset($_POST['submit_btn']))
	{
		$email_id	=	$_POST['user_email'];
		$password	=	$_POST['password'];
		
		if(strlen($password)<6)
		{
			$password_error	=	"Please enter at least 6 characters in password";
			$flag	=	1;
		}
		
		if($flag==0)
		{
			$db_password = $db->get_user_password($email_id);
			
			if($db_password!="")
			{
				if($db_password==$password)
				{
					$_SESSION['current_login_user']	=	$email_id;
					
					header("Location:/user/index.php");
					
				}
				else{
					echo "Incorrect Password";
				}
			}
			else
			{
				echo "This is user is not exist";
			}
		}
		
		
	}
?>
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body bgcolor="#ebd5e0">
<center>
	<?php
		require_once('header.php');
	?>
	<form action="/sign-in.php" method="post">
	<div class="sign_in"style="background-image:url('/images/back.jpg')">
	
		<input type="email" name="user_email" class="f_textbox1" placeholder="Enter your email ID" style="margin-top:50px;" required />
		
		<input type="password" name="password" class="f_textbox1" placeholder="Enter password" required /><br />
		<span class="error_indicator"><?php echo $password_error; ?></span>
	    <center><input type="submit" name="submit_btn" class="submit_btn" value="LOG IN"  />
		
		<br>
		<a href="/forgot-password.php" class="signin_link">Forgot Passwod....?</a></center>
	</div>
	</form>
	<?php
	require_once('footer.php');
	?>
</center>
</body>
</html>