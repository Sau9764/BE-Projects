-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2017 at 01:43 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `instagram_application`
--
CREATE DATABASE IF NOT EXISTS `instagram_application` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `instagram_application`;

-- --------------------------------------------------------

--
-- Table structure for table `application_users`
--

CREATE TABLE IF NOT EXISTS `application_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email_id` text NOT NULL,
  `contact_no` text NOT NULL,
  `gender` text NOT NULL,
  `dob` date NOT NULL,
  `password` text NOT NULL,
  `profile_image` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `application_users`
--

INSERT INTO `application_users` (`id`, `name`, `email_id`, `contact_no`, `gender`, `dob`, `password`, `profile_image`, `date`, `time`) VALUES
(1, 'Shree', 'Shree@hg.com', '4512457845', 'Male', '2017-05-16', 'password', '', '2017-05-17', '02:48:31 31'),
(9, 'shrikant Kadam', 'shree@gmail.com', '9595775120', 'Male', '2017-05-17', '123456', 'LuT50CHuQX.jpg', '2017-05-17', '13:05:02'),
(10, 'shrikant', 'shree@gmail1.com', '9595775120', 'Male', '2017-05-17', 'password', '', '2017-05-17', '13:09:24'),
(11, 'saurabh kekade', 's@gmail.com', '9876543210', 'Male', '1999-06-09', 'saurabh', '', '2004-12-31', '18:46:26');

-- --------------------------------------------------------

--
-- Table structure for table `follow_groups`
--

CREATE TABLE IF NOT EXISTS `follow_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` text NOT NULL,
  `followed_by` text NOT NULL,
  `date` text NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `follow_groups`
--

INSERT INTO `follow_groups` (`id`, `category_id`, `followed_by`, `date`, `time`) VALUES
(2, '3', 'S@GMAIL.COM', '2017-05-27', '13:46:52'),
(3, '2', 's@gmail.com', '2017-05-29', '13:20:03');

-- --------------------------------------------------------

--
-- Table structure for table `insta_groups`
--

CREATE TABLE IF NOT EXISTS `insta_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` text NOT NULL,
  `group_name` text NOT NULL,
  `profile_img` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `insta_groups`
--

INSERT INTO `insta_groups` (`id`, `created_by`, `group_name`, `profile_img`, `date`, `time`) VALUES
(1, 'shree@gmail.com', 'ABC', 'JQHWLd3sYX.gif', '2017-05-27', '13:45:29'),
(2, 'shree@gmail.com', 'XYZ', '49IxQeOVYq.gif', '2017-05-27', '13:45:39'),
(3, 'shree@gmail.com', 'ATSFS', 'UWdJBt66zB.jpg', '2017-05-27', '13:45:52'),
(4, 'shree@gmail.com', 'FSDFSDF', 'uBEhYYb0Ep.jpg', '2017-05-27', '13:45:59'),
(5, 's@gmail.com', 'SAURABH', 'AyWYv9ve9T.jpg', '2017-05-29', '13:22:19'),
(6, 's@gmail.com', 'SSSSSSSSSSSSSSS', 'kdsm8iWD9j.jpg', '2017-05-29', '13:22:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_posts`
--

CREATE TABLE IF NOT EXISTS `user_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` text NOT NULL,
  `image_name` text NOT NULL,
  `posted_by` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user_posts`
--

INSERT INTO `user_posts` (`id`, `group_id`, `image_name`, `posted_by`, `date`, `time`) VALUES
(1, '', 'xk4AJx9ZtP.jpg', 'shree@gmail.com', '2017-05-29', '13:56:58'),
(2, '', '4Pfk4Z2BRN.jpg', 'shree@gmail.com', '2017-05-29', '14:06:35'),
(3, '', 'hLG5XpddxB.jpg', 'shree@gmail.com', '2017-05-29', '14:11:46'),
(4, '2', 'o5QrIVyp00.jpg', 'shree@gmail.com', '2017-05-30', '06:51:47pm'),
(5, '2', 'AMmwNvodw5.jpg', 'shree@gmail.com', '2017-05-30', '06:52:54pm'),
(6, '1', 'ohyRPTy277.jpg', 'shree@gmail.com', '2017-05-30', '06:53:10pm'),
(7, '2', 'JqbSTCnrlX.jpg', 'shree@gmail.com', '2017-05-30', '07:02:45pm'),
(8, '1', '9LXVY7FkbQ.jpg', 'shree@gmail.com', '2017-05-30', '07:08:51pm');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
