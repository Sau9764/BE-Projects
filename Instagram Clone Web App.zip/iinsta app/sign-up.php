<?php
	require_once('lib/db_functions.php');
	
	$db = new database_functions();

	$contact_number_error	=	"";
	$gender_error			=	"";
	$password_error			=	"";
	$conf_password_error	=	"";
	$captcha_code_error		=	"";
	$common_msg				=	"";
	
	
	$flag	=	0;
	
	if(isset($_POST['submit_btn']))
	{
		$user_name		=	$_POST['user_name'];
		$user_email		=	$_POST['user_email'];
		$user_contact_no=	$_POST['contact_number'];
		$user_gender	=	$_POST['user_gender'];
		$user_dob		=	$_POST['dob'];
		$user_password	=	$_POST['password'];
		$user_conf_pwd	=	$_POST['confirm_password'];
		$user_orginal_captcha	=	$_POST['generated_captcha'];
		$user_captcha	=	$_POST['user_captcha'];
		
		if(!is_numeric($user_contact_no))
		{
			$contact_number_error	=	"Please enter numeric contact number";
			$flag	=	1;
		}
		else if(strlen($user_contact_no)!=10)
		{
			$contact_number_error	=	"Please enter valid 10 digit contact number";	
			$flag	=	1;
		}
		
		if($user_gender=="Select Gender")
		{
			$gender_error	=	"Please select gender";
			$flag	=	1;
		}
		
		if(strlen($user_password)<6)
		{
			$password_error	=	"Please enter at least 6 characters in password";
			$flag	=	1;
		}
		else if($user_password!=$user_conf_pwd)
		{
			$conf_password_error	=	"Please match confirm password";
			$flag	=	1;
		}

		if($user_orginal_captcha!=$user_captcha)
		{
			$captcha_code_error	=	"Please enter correct verification code";
			$flag	=	1;
		}
		
		if($flag==0)
		{
			$user_exist	=	$db->get_user_exist_value($user_email);
			
			if($user_exist=="")
			{
				//Save the data
				if($db->register_user($user_name,$user_email,$user_contact_no,$user_gender,$user_dob,$user_password))
				{
					$common_msg	= "Registration successful";
				}
				else{
					$common_msg	= "Failed";
				}
			}
			else
			{
				$common_msg	= "This user is already exist";
			}
		}
		
	}

?>
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  
</head>
<body>
	
	<?php
		require_once('header.php');
	?>
	
	<div class="middle_container" style="background-image:url('/images/back.jpg')">
		<form action="/sign-up.php" method="post">
		<div class="form_container">
			
			<div class="common_msg">
			<?php
				echo $common_msg;
			?>
			</div>
			
			<input type="text" name="user_name" class="f_textbox" placeholder="Enter your name" required />
			
			<input type="email" name="user_email" class="f_textbox" placeholder="Enter your email ID" required />
			
			<input type="text" name="contact_number" class="f_textbox" placeholder="Enter Your Contact Number" required />
			<span class="error_indicator"><?php echo $contact_number_error; ?></span>
			<select name="user_gender" class="f_textbox">
				<option value="Select Gender">Select Gender</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
			<span class="error_indicator"><?php echo $gender_error; ?></span>
			<input type="text" name="dob" class="f_textbox" placeholder="Enter your DOB" id="datepicker" required />
			
			<input type="password" name="password" class="f_textbox" placeholder="Enter password" required />
			<span class="error_indicator"><?php echo $password_error; ?></span>
			<input type="password" name="confirm_password" class="f_textbox" placeholder="Enter confirm password" required />
			<span class="error_indicator"><?php echo $conf_password_error; ?></span>
			<?php
				function generateRandomString($length = 5) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) {
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
			?>
			
			<input type="text" name="generated_captcha" class="f_textbox" value="<?php echo generateRandomString(); ?>" style="padding:10px; font-size:17px; font-weight:bold; text-align:center;" readonly />
			
			<input type="text" name="user_captcha" class="f_textbox" placeholder="Enter captcha code" required />
			<span class="error_indicator"><?php echo $captcha_code_error; ?></span>
			<center><input type="submit" name="submit_btn" class="submit_btn" value="REGISTER ME" />
			
			<br />
			
			<a href="/sign-in.php" class="signin_link">Already Registered? Sign In Here</a></center>
				
		</div>
		</form>
	</div>
	
	<?php
		require_once('footer.php');
	?>
	
</body>
</html>