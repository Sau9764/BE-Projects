<?php
	require_once('lib/db_functions.php');
	
	$db = new database_functions();
	
	$flag	=	0;
	$email_error	="";
	$success_msg	=	"";
	
	if(isset($_POST['submit_btn']))
	{
		$email_id	=	$_POST['user_email'];
		
		if($flag==0)
		{
			$db_password = $db->get_user_password($email_id);
			
			if($db_password!="")
			{
				//Send Email
				
				
				$to	=	$email_id;
				$subject	=	"PASSWORD RECOVERY - INSTAGRAM APPLICATION";
				$message	=	"Dear User, <br /> Your account login credentials are : <br /> Email Id - ".$email_id." <br /> Password - ".$db_password;
				
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <instagram@application.com>' . "\r\n";

				if(mail($to,$subject,$message,$headers))
				{
					$success_msg	=	"Your password sent on your email";
				}
				else
				{
					$success_msg	=	"Failed";
				}
			}
			else
			{
				$email_error	= "This is user is not exist";
			}
		}
		
		
	}
?>
<html>
<head>
	<title>INSTAGRAM APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body bgcolor="#ebd5e0">
<center>
	<?php
		require_once('header.php');
	?>
	<form action="/forgot-password.php" method="post">
	<div class="sign_in"style="background-image:url('/images/back.jpg')">
		<div class="common_msg">
			<?php
				echo $success_msg;
			?>
		</div>
			
		<input type="email" name="user_email" class="f_textbox1" placeholder="Enter your email ID" style="margin-top:50px;" required /><br />
		<span class="error_indicator"><?php echo $email_error; ?></span>
		
	    <center><input type="submit" name="submit_btn" class="submit_btn" value="SEND MY PASSWORD"  />
		
		<br>
		<a href="/sign-in.php" class="signin_link">Know Password? Sign In Here</a></center>
	</div>
	</form>
	<?php
	require_once('footer.php');
	?>
</center>
</body>
</html>