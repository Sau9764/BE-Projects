const express = require('express')
const morgan = require('morgan')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const ejs = require('ejs')
const ejs_mate = require('ejs-mate')
const cookieParser = require('cookie-parser')
const session = require('express-session')
const flash = require('express-flash');
const MongoStore = require('connect-mongo')(session)
const passport = require('passport')

const secret = require('./config/secret')
var User = require('./models/user');
var Category = require('./models/category')
var cartLength = require('./middlewares/middlewares');

const app = express()

app.listen(secret.port, function(err){
    if(err) throw err
    console.log('Server Running ..')
})

//Set up mongoose connection
try{
    // for removing warning
    mongoose.set('useUnifiedTopology', true);
    // connected to atlas cluster
    mongoose.connect(secret.database, { useNewUrlParser: true });
    // check the connection
    var db = mongoose.connection;
    console.log('Database Connected.')
}catch(err){
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
}

// middleware

app.use(express.static(__dirname + '/public'))
app.use(morgan('combined'))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))
// app.use(cookieParser)
app.use( session({ 
    secret: secret.secretkey, 
    resave: true, 
    saveUninitialized: true ,
    store: new MongoStore({
        url: secret.database,
        autoReconnect: true
    })
}))
app.use(flash())
app.use(passport.initialize())
app.use(passport.session())
app.use(function(req, res, next) {
    res.locals.user = req.user;
    next();
});
app.use(cartLength);
app.use(function(req, res, next) {
    Category.find({}, function(err, categories) {
      if (err) return next(err);
      res.locals.categories = categories;
      next();
    });
  });

app.engine('ejs', ejs_mate)
app.set('view engine', 'ejs')

// routes
var mainRoutes = require('./routes/main');
var userRoutes = require('./routes/user');
var adminRoutes = require('./routes/admin')
var apiRoutes = require('./api/api')

app.use(mainRoutes)
app.use(userRoutes)
app.use(adminRoutes)
app.use('/api', apiRoutes)

