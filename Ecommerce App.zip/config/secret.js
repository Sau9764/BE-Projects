module.exports = {
    database : 'mongodb+srv://root:root123@cluster0-bucjl.mongodb.net/ecommerce?retryWrites=true&w=majority',
    port : 9000,
    secretkey : 'secret'
}